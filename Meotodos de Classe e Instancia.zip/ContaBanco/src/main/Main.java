/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import conta.Conta;
import java.util.Scanner;

/**
 *
 * @author MatheusF
 */
public class Main {
    public static void main(String[] args) {
        Conta c1 = new Conta();
        Conta c2 = new Conta();
        
        c1.numeroAgencia = "123-2";
        c1.numeroConta = "123-2";
        
        Conta.depositar(c2, 200);
        
        c2.transferir(c1, 150);
        
        Conta.depositar(c2, 200);
        System.out.println("");
        
        
        //Metodos de Classe e Instancia
        

    }
}
